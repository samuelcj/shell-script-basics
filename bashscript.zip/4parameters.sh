#!/bin/bash

num_files=$1
echo $num_files

 
